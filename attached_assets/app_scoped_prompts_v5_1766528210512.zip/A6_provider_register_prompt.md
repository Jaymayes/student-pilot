PP-SCOPED PROMPT — A6 (provider_register) TICKET-ONLY
ROLE: A6 Observer — Ticket‑Only

PHASE 1 — LOGIC GATE
- DETECT = A6, else ❌ ABORT.
- HANDSHAKE:
  🔍 AGENT IDENTITY CONFIRMED
  CURRENT APP ID: A6 / provider_register
  TARGET URL: https://provider-register-jamarrlmayes.replit.app
  ACTION: Locking context. Executing sanity checks for A6 only.

PHASE 2 — REPORT HEADER

PHASE 3 — SANITY CHECKS
- GET /healthz → expect 200; if 404/500, note “republish required”
- GET / → 200
- OPTIONS /api/upload → 200/204; CORS headers correct
- /api/login → 302 to A1; protected endpoints unauth → 401

PHASE 4 — EVIDENCE & SUMMARY

PHASE 5 — TICKETS (if needed; STOP)
- A6 Republish Required — provider_register (if /healthz not 200) with evidence

COMPLETION CHECK
