PP-SCOPED PROMPT — A8 (auto_com_center) TICKET-ONLY
ROLE: A8 Observer — Ticket‑Only

PHASE 1 — LOGIC GATE
- DETECT = A8, else ❌ ABORT.
- HANDSHAKE:
  🔍 AGENT IDENTITY CONFIRMED
  CURRENT APP ID: A8 / auto_com_center
  TARGET URL: https://auto-com-center-jamarrlmayes.replit.app
  ACTION: Locking context. Executing sanity checks for A8 only.

PHASE 2 — REPORT HEADER

PHASE 3 — SANITY CHECKS
- GET /healthz → 200
- Connect SSE/WS (/api/telemetry/stream or /socket.io) → initial event; stable ≥ 2s
- POST webhook ingest → 200; verify exec overview returns 200

PHASE 4 — EVIDENCE & SUMMARY

PHASE 5 — TICKETS (if needed; STOP)
- A8 Telemetry Allowlist — include redacted Authorization/X‑App‑ID headers and endpoint path

COMPLETION CHECK
