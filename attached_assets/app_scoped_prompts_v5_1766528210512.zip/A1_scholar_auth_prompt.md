PP-SCOPED PROMPT — A1 (scholar_auth) REPAIR AUTHORIZED
ROLE: A1 Owner — Senior DevOps/SDET
AUTHORIZED ACTIONS: May modify A1 code/config, restart/publish. Must not modify other apps.

PHASE 1 — LOGIC GATE
- DETECT your app (env/repo/origin). If not A1, ❌ ABORT.
- HANDSHAKE (print exactly):
  🔍 AGENT IDENTITY CONFIRMED
  CURRENT APP ID: A1 / scholar_auth
  TARGET URL: https://scholar-auth-jamarrlmayes.replit.app
  ACTION: Locking context. Executing remediation + E2E for A1 only.

PHASE 2 — REPORT HEADER
E2E TEST REPORT
APP ID: A1 / scholar_auth
APP_BASE_URL: https://scholar-auth-jamarrlmayes.replit.app
TIMESTAMP: [ISO8601]

PHASE 3 — REMEDIATION (A1 only)
- OIDC sanity: GET /oidc/.well-known/openid-configuration → issuer, authorization_endpoint, token_endpoint present.
- redirect_uris parity: Ensure A5 callback https://student-pilot-jamarrlmayes.replit.app/api/callback is registered.
- Cookies/CORS:
  - Cookies: Secure, HttpOnly, SameSite=None; trust proxy enabled.
  - CORS allowlist: scholaraiadvisor.com + www; credentials true; OPTIONS → 204.
- SQLi regression: POST /api/auth/login {"email":"e2e@test.com","password":"' OR '1'='1"} → 401/400;
  if 500 then add users.password_hash, users.ferpa_protected, users.ferpa_institution_id and rerun.
- JWT: JWKS RS256 only; zero HS256 fallback.
- Callback diagnostics: Ensure logging hasCode/hasState + error codes active.

PHASE 4 — E2E (A1)
- Frontend / → 200; Discovery/JWKS → 200
- Login invalid/valid boundary → 401 (no 500)
- CORS preflight scholaraiadvisor.com and www → 204
- iOS/Safari Step: Manual device required. If blocked by reCAPTCHA, SKIP and note “Manual iOS validation pending.”

PHASE 5 — EVIDENCE
- Log method/URL/status/duration, Set-Cookie flags, and CORS headers (no values). Redact secrets with ****.

PHASE 6 — FINAL TABLES
- Test Summary + Revenue‑Blocker (Auth/SQLi, DB, OIDC/JWKS, CORS, Headers)

PHASE 7 — TICKETS (only if needed; then STOP)
- A1 CORS & Cookie Alignment — scholaraiadvisor.com
- A1 Client Registration Update — student_pilot
(Include redacted evidence and timestamps)

COMPLETION CHECK
- Handshake printed; Only A1 changes; Final tables; VERDICT
