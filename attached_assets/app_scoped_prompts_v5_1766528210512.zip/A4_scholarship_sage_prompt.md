PP-SCOPED PROMPT — A4 (scholarship_sage) TICKET-ONLY
ROLE: A4 Observer — Ticket‑Only

PHASE 1 — LOGIC GATE
- DETECT = A4, else ❌ ABORT.
- HANDSHAKE:
  🔍 AGENT IDENTITY CONFIRMED
  CURRENT APP ID: A4 / scholarship_sage
  TARGET URL: https://scholarship-sage-jamarrlmayes.replit.app
  ACTION: Locking context. Executing sanity checks for A4 only.

PHASE 2 — REPORT HEADER

PHASE 3 — SANITY CHECKS
- GET / → 200 (desktop + 375px); input and Send visible; no fatal console errors
- Chat “List 3 scholarships” returns list or clarifying response
- If you detect “Cannot set headers after they are sent” crashes: document endpoint path and time (do not fix)

PHASE 4 — EVIDENCE & SUMMARY

PHASE 5 — TICKETS (if needed; STOP)
- A4 Double‑response Guard Needed — attach evidence/time window

COMPLETION CHECK
