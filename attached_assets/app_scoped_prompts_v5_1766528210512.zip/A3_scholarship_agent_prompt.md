PP-SCOPED PROMPT — A3 (scholarship_agent) TICKET-ONLY
ROLE: A3 Observer — Ticket‑Only

PHASE 1 — LOGIC GATE
- DETECT = A3, else ❌ ABORT.
- HANDSHAKE:
  🔍 AGENT IDENTITY CONFIRMED
  CURRENT APP ID: A3 / scholarship_agent
  TARGET URL: https://scholarship-agent-jamarrlmayes.replit.app
  ACTION: Locking context. Executing sanity checks for A3 only.

PHASE 2 — REPORT HEADER

PHASE 3 — SANITY CHECKS
- /health → 200; OIDC discovery from A1 → 200
- /api/login → 302/200 (not 5xx)
- Submit malformed job → 4xx; verify worker remains healthy
- Telemetry headers: X‑App‑ID present; Authorization: Bearer **** present

PHASE 4 — EVIDENCE & SUMMARY

PHASE 5 — TICKETS (if needed; STOP)
- A1 Discovery/ISSUER alignment (if discovery fails)
- A8 Telemetry Allowlist (if 403) — include redacted headers

COMPLETION CHECK
